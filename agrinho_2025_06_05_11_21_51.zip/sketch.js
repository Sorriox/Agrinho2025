let gameState = 0; // 0: Colheita, 1: Carregando Caminhão, 2: Dirigindo, 3: Celebrando

// Variáveis do Fazendeiro (Jogador)
let farmerX, farmerY;
let farmerSize = 30;
let farmerSpeed = 3;

// Variáveis da Comida
let foodItems = [];
let maxFood = 7; // Quantidade de comida para coletar para cada "carga"
let foodSize = 25;
let collectedFoodCount = 0;

// Variáveis do Caminhão
let truckX, truckY;
let truckWidth = 100;
let truckHeight = 60;
let truckSpeed = 2;
let truckLoaded = false;
let truckDocked = false; // Indica se o caminhão está parado para carregar

// Imagens (Opcional, mas muito recomendado para o visual do jogo)
// Se você tiver imagens, pode carregá-las aqui!
// let farmerImg;
// let foodImg; // Ex: abóbora, cenoura
// let truckImg;
// let cityImg; // Imagem de fundo da cidade
// let celebrationImg; // Ex: confetes, fogos de artifício

function preload() {
  // --- CARREGUE SUAS IMAGENS AQUI! ---
  // Descomente e substitua 'assets/nome_da_imagem.png' pelos seus próprios caminhos:
  // farmerImg = loadImage('/home/escola/Downloads/images.png');
  // foodImg = loadImage('assets/abobora.png');
  // truckImg = loadImage('assets/caminhao.png');
  // cityImg = loadImage('assets/cidade.png');
  // celebrationImg = loadImage('assets/celebracao.png');
}

function setup() {
  createCanvas(800, 600); // Cria a tela do jogo
  farmerX = width / 2;    // Posição inicial do fazendeiro
  farmerY = height - 120; // Perto do chão
  resetGame(); // Inicializa todos os elementos do jogo
}

function resetGame() {
  gameState = 0;
  collectedFoodCount = 0;
  foodItems = []; // Limpa a comida anterior
  truckLoaded = false;
  truckDocked = false;
  truckX = width + 150; // Caminhão começa fora da tela, à direita
  truckY = height - 90; // Posição Y do caminhão (no chão)
  spawnFood(maxFood); // Gera a comida no campo
}

function spawnFood(num) {
  for (let i = 0; i < num; i++) {
    foodItems.push({
      x: random(foodSize, width - foodSize),             // Posição X aleatória
      y: random(foodSize, height - foodSize - 150),      // Posição Y aleatória (evita a área do chão e do caminhão)
      isCollected: false                                 // Indica se a comida foi coletada
    });
  }
}

function draw() {
  background(135, 206, 235); // Cor de fundo: azul céu
  drawGround(); // Desenha o chão do campo

  handleInput(); // Verifica a entrada do teclado para movimento

  if (gameState === 0) { // Fase de Colheita
    drawFarmer();
    drawFood();
    checkFoodCollection();
    drawCollectedFoodCount(); // Mostra a contagem de comida

    if (collectedFoodCount >= maxFood) {
      gameState = 1; // Mude para a fase de carregamento do caminhão
    }
  } else if (gameState === 1) { // Fase de Carregamento do Caminhão
    drawFarmer();
    drawTruck();
    // Move o caminhão para a posição de carga
    if (truckX > width - truckWidth - 50 && !truckDocked) {
        truckX -= truckSpeed;
    } else {
        truckDocked = true; // Caminhão está na posição
        checkTruckLoading();
    }
    drawCollectedFoodCount();

  } else if (gameState === 2) { // Fase de Dirigindo para a Cidade
    drawTruck();
    moveTruckToCity();
    // Opcional: Desenhe a cidade ao fundo enquanto o caminhão se move
    // if (cityImg) image(cityImg, truckX - width, 0, width, height);
  } else if (gameState === 3) { // Fase de Celebração na Cidade
    drawCelebration();
  }
}

function drawGround() {
  fill(100, 150, 50); // Cor do chão: verde de campo
  rect(0, height - 100, width, 100); // Faixa inferior para o chão
}

function handleInput() {
  if (keyIsDown(LEFT_ARROW)) {
    farmerX -= farmerSpeed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    farmerX += farmerSpeed;
  }
  if (keyIsDown(UP_ARROW)) {
    farmerY -= farmerSpeed;
  }
  if (keyIsDown(DOWN_ARROW)) {
    farmerY += farmerSpeed;
  }

  // Mantém o fazendeiro dentro dos limites da tela, evitando a área do chão
  farmerX = constrain(farmerX, farmerSize / 2, width - farmerSize / 2);
  farmerY = constrain(farmerY, farmerSize / 2, height - 100 - farmerSize / 2);
}

function drawFarmer() {
  fill(255, 0, 0); // Círculo vermelho para o fazendeiro
  ellipse(farmerX, farmerY, farmerSize, farmerSize);
  // Se você tiver uma imagem: image(farmerImg, farmerX - farmerSize/2, farmerY - farmerSize/2, farmerSize, farmerSize);
}

function drawFood() {
  for (let food of foodItems) {
    if (!food.isCollected) {
      fill(255, 150, 0); // Laranja para a comida (ex: abóbora)
      ellipse(food.x, food.y, foodSize, foodSize);
      // Se você tiver uma imagem: image(foodImg, food.x - foodSize/2, food.y - foodSize/2, foodSize, foodSize);
    }
  }
}

function checkFoodCollection() {
  for (let food of foodItems) {
    if (!food.isCollected) {
      let d = dist(farmerX, farmerY, food.x, food.y); // Distância entre fazendeiro e comida
      if (d < farmerSize / 2 + foodSize / 2) {
        food.isCollected = true;
        collectedFoodCount++;
      }
    }
  }
}

function drawCollectedFoodCount() {
    fill(0); // Cor do texto: preto
    textSize(18);
    text(`Comida Coletada: ${collectedFoodCount}/${maxFood}`, 10, 30); // Mostra a contagem
}

function drawTruck() {
  fill(150, 75, 0); // Marrom para o corpo do caminhão
  rect(truckX, truckY, truckWidth, truckHeight);
  fill(50); // Cinza escuro para as rodas
  ellipse(truckX + 25, truckY + truckHeight, 30, 30);
  ellipse(truckX + truckWidth - 25, truckY + truckHeight, 30, 30);
  // Se você tiver uma imagem: image(truckImg, truckX, truckY, truckWidth, truckHeight);
}

function checkTruckLoading() {
    // Verifica se o fazendeiro está perto do caminhão para "carregar"
    let d = dist(farmerX, farmerY, truckX + truckWidth / 2, truckY + truckHeight / 2);
    if (d < farmerSize / 1 + truckWidth / 3 && !truckLoaded) {
        truckLoaded = true;
        gameState = 2; // Mude para a fase de dirigir para a cidade
    }
}

function moveTruckToCity() {
  truckX -= truckSpeed; // Move o caminhão para a esquerda
  if (truckX < -truckWidth) { // Se o caminhão saiu da tela pela esquerda
    gameState = 3; // Mude para a fase de celebração
  }
}

function drawCelebration() {
  background(255, 255, 0); // Fundo amarelo vibrante para a celebração
  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("🥳 COLHEITA BEM-SUCEDIDA! 🥳", width / 2, height / 2 - 20);
  textSize(32);
  text("🎉 A CIDADE ESTÁ FESTEJANDO! 🎉", width / 2, height / 2 + 30);
  // Se você tiver uma imagem: image(celebrationImg, 0, 0, width, height);

  // Botão para reiniciar o jogo
  fill(0, 150, 0);
  rect(width / 2 - 75, height / 2 + 90, 150, 40);
  fill(255);
  textSize(24);
  text("REINICIAR", width / 2, height / 2 + 115);
}

function mousePressed() {
    if (gameState === 3) {
        // Verifica se o botão de reiniciar foi clicado
        if (mouseX > width / 2 - 75 && mouseX < width / 2 + 75 &&
            mouseY > height / 2 + 90 && mouseY < height / 2 + 130) {
            resetGame(); // Reinicia o jogo
        }
    }
}